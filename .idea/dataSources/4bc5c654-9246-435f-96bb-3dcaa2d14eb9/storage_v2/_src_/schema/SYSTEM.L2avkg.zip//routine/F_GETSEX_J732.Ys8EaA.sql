create function f_getSex_J732 return varchar2
--is
--f_num number;
--f_sex varchar2(6);
--begin
--select trunc(dbms_random.value(1,143)) into f_num from dual;
--if f_num<=71 then 
--  f_sex:='男';
--elsif f_num<=142 then
--  f_sex:='女';
--else
--  f_sex:='其他';
--end if;
--return f_sex;
--end;
/

